#include <stdio.h>
#include <unistd.h>

int main() {
	for(;;){
		printf("I Love SCOMP!\n");
		sleep(1);
	}
}

/*
 * SIGSTOP - stop process 
 * SIGCONT - continue process
 * SIGKILL - kill process(end process)
 * 
 * 
 * 
 * 
 *
 */
